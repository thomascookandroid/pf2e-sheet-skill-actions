export const BASIC_ACTIONS_MODULE_NAME = 'pf2e-sheet-basic-actions';

export function registerSettings(): void {

}
